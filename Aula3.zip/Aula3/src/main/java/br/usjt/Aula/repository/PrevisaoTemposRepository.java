package br.usjt.Aula.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import br.usjt.Aula.model.PrevisaoTempo;

public interface PrevisaoTemposRepository extends JpaRepository<PrevisaoTempo, Long>{

}
