insert into previsaoTempo (nome,temp_min, temp_max, humidade, dataHora, latitude, longitude, descricao) values ('14 de abril', 22.3,15.8, 12.7,'14/04 15:35',2234,4323,'humido');
insert into previsaoTempo (nome,temp_min, temp_max, humidade, dataHora, latitude, longitude, descricao) values ('7 de março', 17.3,12.4, 9.5,'07/03 5:35',7382,5637,'seco');
insert into previsaoTempo (nome,temp_min, temp_max, humidade, dataHora, latitude, longitude, descricao) values ('9 de julho', 20.1,16.6, 15.8,'09/06 22:16',3252,4740,'chuvoso');

insert into usuario (id, login, senha) values (1, 'admin', 'admin')