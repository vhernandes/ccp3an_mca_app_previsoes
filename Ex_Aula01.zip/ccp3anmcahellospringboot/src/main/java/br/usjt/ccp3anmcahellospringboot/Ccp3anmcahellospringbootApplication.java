package br.usjt.ccp3anmcahellospringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ccp3anmcahellospringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ccp3anmcahellospringbootApplication.class, args);
	}

}
