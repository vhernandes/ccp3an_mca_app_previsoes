insert into alunos (id, nome, media_notas) values (1, 'Ana', 10);
insert into alunos (id, nome, media_notas) values (2, 'Maria', 3);
insert into alunos (id, nome, media_notas) values (3, 'Ricardo', 7);
